
import { useState } from "react";
import { Sun, Moon } from "lucide-react";

export default function Portfolio() {
  const [darkMode, setDarkMode] = useState(false);

  return (
    <div className={darkMode ? "dark bg-gray-900 text-white" : "bg-white text-gray-900"}>
      <header className="flex justify-between items-center p-6 shadow-md">
        <h1 className="text-2xl font-bold">Nitheeshkumar Dama</h1>
        <button onClick={() => setDarkMode(!darkMode)}>
          {darkMode ? <Sun className="w-6 h-6" /> : <Moon className="w-6 h-6" />}
        </button>
      </header>

      <main className="p-6 space-y-12">
        <section>
          <h2 className="text-xl font-semibold mb-2">About Me</h2>
          <p>
            Proficient Technology Management in Supply Chain Management graduate student with expertise
            in logistics, operations, and HR across tech, e-commerce, and military sectors. Passionate about
            driving product innovation and delivering measurable outcomes.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold mb-2">Skills</h2>
          <ul className="list-disc pl-6">
            <li>Languages: C, Python</li>
            <li>Web: HTML, CSS</li>
            <li>Database: SQL</li>
            <li>Tools: MS Office, Lean Six Sigma, Agile, DMAIC, SPC</li>
            <li>Languages: English, Telugu, Hindi</li>
          </ul>
        </section>

        <section>
          <h2 className="text-xl font-semibold mb-2">Education</h2>
          <ul className="list-disc pl-6">
            <li>MS in Technology Management, Univ. of Bridgeport (Dec 2025)</li>
            <li>BSc in Math, Electronics, CS – Sri Venkateswara Arts College (2020)</li>
          </ul>
        </section>

        <section>
          <h2 className="text-xl font-semibold mb-2">Experience</h2>
          <div>
            <h3 className="font-bold">FNP Store, Manager (2021–2024)</h3>
            <ul className="list-disc pl-6">
              <li>Managed global order fulfillment and reduced delivery turnaround by 20%</li>
              <li>Improved procurement and inventory procedures</li>
            </ul>
            <h3 className="font-bold mt-4">MARS Infosol, HR/Support Executive (2021–2023)</h3>
            <ul className="list-disc pl-6">
              <li>Led hiring, onboarding, wellness initiatives and Lean Six Sigma implementations</li>
            </ul>
          </div>
        </section>

        <section>
          <h2 className="text-xl font-semibold mb-2">Projects</h2>
          <ul className="list-disc pl-6">
            <li>Lean Six Sigma for Voter Participation (2025)</li>
            <li>Data-Driven Analysis of CFGC Donations (2025)</li>
            <li>Nike Brand Audit (2024)</li>
            <li>WE FIVE Messenger Development (2024)</li>
          </ul>
        </section>

        <section>
          <h2 className="text-xl font-semibold mb-2">Certifications & Awards</h2>
          <ul className="list-disc pl-6">
            <li>NCC Republic Day Camp & PM’s Rally (2017)</li>
            <li>Karate Brown Belt – 2, Guinness Participant</li>
          </ul>
        </section>

        <section>
          <h2 className="text-xl font-semibold mb-2">Contact</h2>
          <p>Email: nidama@my.bridgeport.edu | Phone: +1 475 201 4038</p>
        </section>
      </main>

      <footer className="text-center p-4 border-t mt-12">
        <p>&copy; {new Date().getFullYear()} Nitheeshkumar Dama</p>
      </footer>
    </div>
  );
}
